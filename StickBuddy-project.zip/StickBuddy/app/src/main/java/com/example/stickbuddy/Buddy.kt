package com.example.stickbuddy

import java.util.Calendar
import kotlin.math.abs
import kotlin.random.Random

enum class Loc { GROUND, WALL, CEIL, AIR, HELD }
enum class Act {
    IDLE, WALK, RUN, SIT, SLEEP, WAVE, JUMP, FLIP, DANCE, LAUGH, TRIP, KUNGFU, WRESTLE,
    VICTORY, ANGRY, THINK, STRETCH, SIGH, DIZZY, CLIMB, HANG, SHUFFLE, HELD, FALLING, LAND
}

/** مغز و رفتار یک آدمک: شخصیت، انرژی، حوصله، حال و هوا. */
class Buddy(val name: String, val u: Float, private val speedMul: Float, val wPx: Int, val hPx: Int) {
    var color: Int = 0xFFFFFFFF.toInt()
    var sw = 0
    var sh = 0
    var statusH = 0f
    var groundY = 0f
    var x = 0f
    var y = 0f
    private var vy = 0f
    var loc = Loc.GROUND
    var act = Act.IDLE
    var t = 0f
    var dur = 2f
    var dir = 1
    var wallSide = 1
    var clock = 0f
    var say: String? = null
    var sayT = 0f

    // شخصیت (ثابت)
    val curious = 0.3f + Random.nextFloat() * 0.6f
    val silly = 0.2f + Random.nextFloat() * 0.7f
    val social = 0.2f + Random.nextFloat() * 0.7f
    val lazy = 0.2f + Random.nextFloat() * 0.7f

    // ذهن (متغیر)
    var energy = 0.85f
    var boredom = 0.55f
    var mood = 0.7f
    private var annoy = 0f

    private var tx = 0f
    private var ty = 0f
    private var playCd = 0f
    private var exploreCd = 45f
    private var speechCd = 4f
    private var socialCd = 30f
    private var thenClimb = false
    private var descend = false
    private var runAfter = false
    private var hangCount = 0
    private var fightResult = 0
    private var impact = 0f
    private var offX = 0f
    private var offY = 0f
    private var others: List<Buddy> = emptyList()

    private fun <T> rnd(vararg a: T): T = a[Random.nextInt(a.size)]

    private fun pickIdx(w: FloatArray): Int {
        var s = 0f
        for (v in w) s += v
        var r = Random.nextFloat() * s
        for (i in w.indices) { r -= w[i]; if (r <= 0f) return i }
        return 0
    }

    private fun maxX(): Float = (sw - wPx).toFloat().coerceAtLeast(0f)

    private fun go(a: Act, d: Float) { act = a; t = 0f; dur = d }

    fun speak(s: String, secs: Float = 2.8f, force: Boolean = false) {
        if (force || (sayT <= 0f && speechCd <= 0f)) {
            say = s; sayT = secs
            speechCd = 14f + Random.nextFloat() * 20f
        }
    }

    fun setScreen(w: Int, h: Int, st: Float) {
        val first = sw == 0
        sw = w; sh = h; statusH = st
        groundY = h - hPx - 8f * u
        if (first) {
            x = Random.nextFloat() * maxX(); y = groundY
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            if (hour >= 23 || hour < 6) energy = 0.35f
            val s = when {
                hour in 5..10 -> "صبح بخیر! ☀️"
                hour in 11..16 -> "سلام! اومدم پیشت 👋"
                hour in 17..21 -> "عصر بخیر!"
                else -> "شب بخیر... خوابم میاد"
            }
            go(Act.WAVE, 2.6f)
            speak(s, 3f, true)
        } else {
            x = x.coerceIn(0f, maxX())
            if (loc == Loc.GROUND) y = groundY
        }
    }

    fun update(dt: Float, all: List<Buddy>) {
        others = all
        clock += dt
        t += dt
        if (sayT > 0f) { sayT -= dt; if (sayT <= 0f) say = null }
        speechCd -= dt; playCd -= dt; exploreCd -= dt; socialCd -= dt
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val night = hour >= 23 || hour < 6
        if (act == Act.SLEEP) energy += dt * 0.012f else energy -= dt * (if (night) 0.005f else 0.0028f)
        energy = energy.coerceIn(0f, 1f)
        if (act != Act.SLEEP) boredom = (boredom + dt * 0.012f).coerceAtMost(1f)
        mood += (0.65f - mood) * dt * 0.02f
        mood = mood.coerceIn(0f, 1f)
        annoy = (annoy - dt * 0.04f).coerceAtLeast(0f)
        when (loc) {
            Loc.GROUND -> groundStep(dt)
            Loc.WALL -> wallStep(dt)
            Loc.CEIL -> ceilStep(dt)
            Loc.AIR -> airStep(dt)
            Loc.HELD -> {}
        }
        if (loc == Loc.GROUND && sayT <= 0f && speechCd <= 0f &&
            (act == Act.IDLE || act == Act.WALK || act == Act.SIT) && Random.nextFloat() < dt * 0.05f) thought()
    }

    private fun thought() {
        val s = when {
            energy < 0.35f -> rnd("خسته شدم...", "چشمام داره بسته می‌شه 😪")
            boredom > 0.6f -> rnd("حوصله‌م سر رفت...", "یه کاری پیدا کنم")
            mood > 0.8f -> rnd("امروز حالم عالیه 😊", "دنیا قشنگه!")
            else -> rnd("هوم... یه پیتزا چه خوب بود 🍕", "آسمون امروز قشنگه", "می‌دونستی من استخون ندارم؟ 😄", "کاش یه دوست بیشتر داشتم", "دارم به معنای زندگی فکر می‌کنم...")
        }
        speak(s)
    }

    // ---------- زمین ----------
    private fun groundStep(dt: Float) {
        y = groundY
        if (act == Act.WALK || act == Act.RUN) {
            val sp = (if (act == Act.RUN) 125f else 46f) * u * speedMul
            val d = tx - x
            if (abs(d) <= sp * dt + 1f) {
                x = tx
                if (thenClimb) beginWall() else decide()
            } else {
                dir = if (d > 0f) 1 else -1
                x += dir * sp * dt
                if (t > dur) decide()
            }
        } else if (t >= dur) {
            onActEnd()
        }
        x = x.coerceIn(0f, maxX())
        trySocial(dt)
    }

    private fun onActEnd() {
        when (act) {
            Act.KUNGFU, Act.WRESTLE -> if (fightResult != 0) {
                if (fightResult > 0) { go(Act.VICTORY, 2.4f); speak("من بردم! 💪", 2.4f, true) }
                else { go(Act.TRIP, 3f); speak("تسلیم! تسلیم!", 2.4f, true) }
                fightResult = 0
                return
            }
            Act.LAND -> if (impact > 520f * u) { go(Act.DIZZY, 2f); return }
            Act.ANGRY -> if (runAfter) {
                runAfter = false
                tx = if (x < sw / 2f) maxX() else 0f
                thenClimb = false
                go(Act.RUN, 8f)
                return
            }
            Act.SLEEP -> {
                if (energy < 0.7f) { t = 0f; dur = 20f; return }
                go(Act.STRETCH, 2.6f); speak("چه خوب خوابیدم! ☀️", 2.6f, true); return
            }
            else -> {}
        }
        decide()
    }

    private fun decide() {
        thenClimb = false
        if (energy < 0.18f) { go(Act.SLEEP, 60f); speak("خوابم میاد... 😴", 3f, true); return }
        if (energy < 0.3f && Random.nextFloat() < 0.5f) { go(Act.SIT, 7f + Random.nextFloat() * 6f); speak("یه کم استراحت کنم"); return }
        val w = FloatArray(6)
        w[0] = 5f
        w[1] = 2.5f
        w[2] = 1f + lazy * 2f
        w[3] = if (boredom > 0.7f && playCd <= 0f) 9f else 0f
        w[4] = if (exploreCd <= 0f && energy > 0.45f) curious * 4f else 0f
        w[5] = if (boredom > 0.5f) 1.5f else 0.6f
        when (pickIdx(w)) {
            0 -> {
                val dd = (120f + Random.nextFloat() * 320f) * u
                val s = if (Random.nextBoolean()) 1 else -1
                var target = x + s * dd
                if (target < 0f || target > maxX()) target = x - s * dd
                val friend = if (others.size > 1 && social > 0.45f && Random.nextFloat() < 0.4f)
                    others.filter { it !== this && it.loc == Loc.GROUND }.randomOrNull() else null
                if (friend != null) target = friend.x + (if (Random.nextBoolean()) -1 else 1) * 70f * u
                tx = target.coerceIn(0f, maxX())
                dir = if (tx > x) 1 else -1
                go(Act.WALK, 60f)
            }
            1 -> { if (Random.nextFloat() < 0.4f) dir = -dir; go(Act.IDLE, 2f + Random.nextFloat() * 3f) }
            2 -> go(Act.SIT, 5f + Random.nextFloat() * 8f)
            3 -> doPlay()
            4 -> beginExplore()
            else -> {
                if (Random.nextBoolean()) { go(Act.THINK, 3.5f); speak(rnd("هوم... نمی‌دونم", "فکر می‌کنم...", "یه فکر خوب دارم!")) }
                else { go(Act.STRETCH, 2.6f) }
            }
        }
    }

    private fun doPlay() {
        val r = Random.nextFloat()
        when {
            r < 0.25f -> { go(Act.FLIP, 1.2f); speak("شقلمه! 🤸", 2f, true) }
            r < 0.5f -> { go(Act.DANCE, 4f); speak("ببین چه می‌رقصم 🎶", 2.4f, true) }
            r < 0.85f -> { fightResult = 0; go(Act.KUNGFU, 4f); speak("هیااا! 🥋", 2.4f, true) }
            else -> { go(Act.JUMP, 1f); speak("هوپ!", 1.6f, true) }
        }
        boredom = 0.05f
        mood = (mood + 0.1f).coerceAtMost(1f)
        playCd = 90f + Random.nextFloat() * 90f
    }

    // ---------- اجتماعی ----------
    private fun trySocial(dt: Float) {
        if (loc != Loc.GROUND || socialCd > 0f || energy < 0.3f) return
        if (act != Act.IDLE && act != Act.WALK) return
        for (o in others) {
            if (o === this || o.loc != Loc.GROUND) continue
            if (o.act != Act.IDLE && o.act != Act.WALK) continue
            if (abs(o.x - x) < 110f * u && Random.nextFloat() < dt * (0.2f + social) * 0.5f) { startSocial(o); return }
        }
    }

    private fun startSocial(o: Buddy) {
        socialCd = 70f + Random.nextFloat() * 60f
        o.socialCd = socialCd
        dir = if (o.x > x) 1 else -1
        o.dir = -dir
        thenClimb = false; o.thenClimb = false
        val r = Random.nextFloat()
        if (r < 0.4f) {
            go(Act.WAVE, 2.4f); o.go(Act.WAVE, 2.4f)
            speak("سلام ${o.name}! 👋", 2.4f, true); o.speak("سلام ${name}!", 2.4f, true)
        } else if (r < 0.7f) {
            o.x = (x + dir * 55f * u).coerceIn(0f, maxX())
            val a = if (Random.nextBoolean()) Act.KUNGFU else Act.WRESTLE
            go(a, 4.5f); o.go(a, 4.5f)
            fightResult = if (Random.nextBoolean()) 1 else -1
            o.fightResult = -fightResult
            speak("هیااا!", 2f, true); o.speak("بیا جلو!", 2f, true)
        } else {
            go(Act.DANCE, 4f); o.go(Act.DANCE, 4f)
            speak("بزن برقصیم! 🎶", 2.4f, true)
        }
    }

    // ---------- دیوار ----------
    private fun beginExplore() {
        exploreCd = 150f + Random.nextFloat() * 150f
        thenClimb = true
        wallSide = if (x + wPx / 2f < sw / 2f) -1 else 1
        tx = if (wallSide < 0) 0f else maxX()
        dir = if (tx > x) 1 else -1
        go(Act.WALK, 40f)
        speak(rnd("بریم یه گشتی بالا!", "هوس کوه‌نوردی کردم 🧗"), 2.6f, true)
    }

    private fun beginWall() {
        thenClimb = false
        loc = Loc.WALL
        x = if (wallSide < 0) 0f else maxX()
        dir = wallSide
        ty = statusH
        go(Act.CLIMB, 999f)
    }

    private fun wallStep(dt: Float) {
        if (act == Act.CLIMB) {
            val sp = 30f * u * speedMul
            val d = ty - y
            if (abs(d) <= sp * dt + 1f) { y = ty; arriveWall() }
            else y += (if (d > 0f) 1f else -1f) * sp * dt
        } else if (t >= dur) {
            ty = if (Random.nextBoolean()) statusH else groundY
            go(Act.CLIMB, 999f)
        }
    }

    private fun arriveWall() {
        if (ty <= statusH + 2f) {
            loc = Loc.CEIL; y = statusH; hangCount = 0
            go(Act.HANG, 2f + Random.nextFloat() * 2f)
            speak(rnd("آویزونم 🙃", "اینجا منظره‌ش خوبه!"), 2.6f, true)
        } else if (ty >= groundY - 2f) {
            loc = Loc.GROUND; y = groundY
            go(Act.IDLE, 1.5f)
        } else {
            go(Act.IDLE, 2.5f)
        }
    }

    // ---------- سقف ----------
    private fun ceilStep(dt: Float) {
        y = statusH
        if (act == Act.SHUFFLE) {
            val sp = 26f * u * speedMul
            val d = tx - x
            if (abs(d) <= sp * dt + 1f) {
                x = tx
                if (descend) {
                    descend = false
                    loc = Loc.WALL; wallSide = if (x < 1f) -1 else 1; dir = wallSide
                    ty = groundY
                    go(Act.CLIMB, 999f)
                } else go(Act.HANG, 2f + Random.nextFloat() * 2f)
            } else {
                dir = if (d > 0f) 1 else -1
                x += dir * sp * dt
            }
        } else if (act == Act.HANG && t >= dur) {
            hangCount++
            if (hangCount >= 3) leaveCeiling()
            else { tx = Random.nextFloat() * maxX(); go(Act.SHUFFLE, 60f) }
        }
        x = x.coerceIn(0f, maxX())
    }

    private fun leaveCeiling() {
        if (Random.nextFloat() < silly) {
            loc = Loc.AIR; vy = 0f; go(Act.FALLING, 99f)
            speak("خداحافظ! ووووی 😆", 2.2f, true)
        } else {
            tx = if (x < maxX() / 2f) 0f else maxX()
            descend = true
            go(Act.SHUFFLE, 60f)
        }
    }

    // ---------- هوا ----------
    private fun airStep(dt: Float) {
        vy += 900f * u * dt
        y += vy * dt
        if (y >= groundY) {
            y = groundY; impact = vy; vy = 0f
            loc = Loc.GROUND
            if (impact > 520f * u) {
                mood = (mood - 0.15f).coerceAtLeast(0f)
                go(Act.LAND, 0.7f)
                speak(rnd("آخ!!", "آی! کمرم!"), 2.4f, true)
            } else go(Act.LAND, 0.35f)
        }
    }

    // ---------- لمس کاربر ----------
    fun grab(rawX: Float, rawY: Float) {
        offX = rawX - x; offY = rawY - y
        loc = Loc.HELD; go(Act.HELD, 9999f)
        thenClimb = false; descend = false
        if (silly > 0.5f) speak(rnd("ووووی! 😆", "پرواز!"), 2.2f, true)
        else speak(rnd("ولم کن!", "کجا می‌بری؟!"), 2.2f, true)
    }

    fun dragTo(rawX: Float, rawY: Float) {
        x = (rawX - offX).coerceIn(0f, maxX())
        y = (rawY - offY).coerceIn(statusH, groundY)
    }

    fun release() {
        if (y <= statusH + 45f * u && (curious > 0.4f || Random.nextFloat() < 0.5f)) {
            loc = Loc.CEIL; y = statusH; hangCount = 1
            go(Act.HANG, 3f)
            speak("گرفتم! 🙃", 2.2f, true)
        } else if ((x <= 14f * u || x >= maxX() - 14f * u) && y < groundY - 40f * u) {
            wallSide = if (x < maxX() / 2f) -1 else 1
            x = if (wallSide < 0) 0f else maxX()
            loc = Loc.WALL; dir = wallSide
            go(Act.IDLE, 2f)
            speak("چسبیدم!", 2f, true)
        } else if (y >= groundY - 4f) {
            loc = Loc.GROUND; y = groundY; go(Act.IDLE, 1f)
        } else {
            loc = Loc.AIR; vy = 0f; go(Act.FALLING, 99f)
        }
    }

    fun poke() {
        annoy += 0.2f
        if (loc == Loc.GROUND) {
            if (act == Act.SLEEP) {
                mood = (mood - 0.1f).coerceAtLeast(0f)
                go(Act.ANGRY, 1.6f); speak("بذار بخوابم... 😠", 2.4f, true)
            } else if (annoy > 0.75f) {
                runAfter = true; annoy = 0.4f
                mood = (mood - 0.1f).coerceAtLeast(0f)
                go(Act.ANGRY, 1.8f); speak(rnd("دیگه بسه!!", "اَه! بس کن دیگه!"), 2.4f, true)
            } else if (mood > 0.45f) {
                if (Random.nextBoolean()) { go(Act.LAUGH, 1.8f); speak(rnd("هاهاها قلقلکم میاد 😂", "هی! نکن!"), 2.4f, true) }
                else { go(Act.JUMP, 0.9f); speak("هوپ!", 1.6f, true) }
                boredom = (boredom - 0.3f).coerceAtLeast(0f)
                mood = (mood + 0.05f).coerceAtMost(1f)
            } else {
                go(Act.SIGH, 2f); speak("آخ... حوصله ندارم", 2.4f, true)
            }
        } else if (loc == Loc.WALL || loc == Loc.CEIL) {
            speak(rnd("قلقلکم نده، می‌افتم!", "هی! داشتم می‌افتادم!"), 2.4f, true)
        }
    }
}

package com.example.stickbuddy

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.*
import kotlin.random.Random

/** آدمک استیک‌فیگور سیاه با دور سفید، تا روی هر پس‌زمینه‌ای دیده شود. */
class StickView(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    var dir = 1
    var act = "walk"
    private var t = 0f
    private var dur = 4f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }

    fun start(a: String) {
        act = a; t = 0f
        dur = when (a) {
            "walk" -> 3f + Random.nextFloat() * 4f
            "jump" -> 0.9f; "flip" -> 1.1f; "dance" -> 3.5f
            "fall" -> 3.2f; "wave" -> 2f; "laugh" -> 2.4f; "sneak" -> 3f
            else -> 2f
        }
    }
    fun step(dt: Float) { t += dt; invalidate() }
    fun finished() = t >= dur

    override fun onDraw(c: Canvas) {
        val pr = t / dur
        var la = 0f; var ra = 0f; var ll = 0f; var rl = 0f
        var lean = 0f; var oy = 0f; var rot = 0f; var squash = 0f
        when (act) {
            "walk" -> { val s = sin(t * 9); ll = s * .7f; rl = -s * .7f; la = -s * .6f; ra = s * .6f; oy = -abs(s) * 3 * d }
            "sneak" -> { val s = sin(t * 5); ll = s * .5f; rl = -s * .5f; lean = .45f; squash = 8 * d; la = .9f; ra = 1.1f }
            "jump" -> { oy = -sin(PI.toFloat() * pr) * 50 * d; la = -2.6f; ra = -2.6f; ll = .3f; rl = -.3f }
            "flip" -> { oy = -sin(PI.toFloat() * pr) * 55 * d; rot = pr * 360f * dir; la = -2.2f; ra = -2.2f; ll = .6f; rl = .6f }
            "dance" -> { val s = sin(t * 9); oy = -abs(s) * 5 * d; la = -2.4f + s; ra = -2.4f - s; ll = s * .5f; rl = -s * .5f + .3f; lean = s * .18f }
            "wave" -> { ra = -2.6f + sin(t * 13) * .35f; la = .2f; ll = .1f; rl = -.1f }
            "laugh" -> { val s = sin(t * 28); oy = -abs(sin(t * 14)) * 4 * d; lean = -.25f + s * .05f; la = -1.2f + s * .3f; ra = -1.2f - s * .3f }
            "fall" -> when {
                pr < .2f -> { lean = pr * 3f; la = -2f; ra = -2f; ll = .5f }
                pr < .35f -> rot = (pr - .2f) / .15f * 90f * dir
                pr < .8f -> { rot = 90f * dir; la = -2f + sin(t * 10) * .3f; ra = -1.6f }
                else -> rot = (1 - (pr - .8f) / .2f) * 90f * dir
            }
        }
        val L = 34 * d; val T = 36 * d; val A = 26 * d; val R = 13 * d
        c.save()
        c.translate(width / 2f, height - 6 * d)
        c.scale(dir.toFloat(), 1f)
        val hipY = -L + squash + oy
        c.rotate(rot * (if (dir < 0) -1 else 1), 0f, hipY - T / 2)
        for (pass in 0..1) {
            p.color = if (pass == 0) Color.WHITE else Color.BLACK
            p.strokeWidth = if (pass == 0) 9 * d else 5 * d
            p.style = Paint.Style.STROKE
            val nx = sin(lean) * T; val ny = hipY - cos(lean) * T
            c.drawLine(0f, hipY, nx, ny, p)
            limb(c, 0f, hipY, ll, L / 2, L / 2, -.35f)
            limb(c, 0f, hipY, rl, L / 2, L / 2, -.35f)
            val sx = nx * .9f; val sy = ny + 4 * d
            limb(c, sx, sy, la, A / 2, A / 2, .55f)
            limb(c, sx, sy, ra, A / 2, A / 2, .55f)
            val hx = nx + sin(lean) * R; val hy = ny - cos(lean) * R
            c.drawCircle(hx, hy, R, p)
            if (pass == 1) {
                p.style = Paint.Style.FILL
                val open = act == "laugh"
                c.drawCircle(hx + 4 * d, hy - 2 * d, 1.6f * d, p)
                c.drawCircle(hx - 2 * d, hy - 2 * d, 1.6f * d, p)
                if (open) c.drawCircle(hx + 1 * d, hy + 4 * d, 3 * d, p)
            }
        }
        c.restore()
    }

    private fun limb(c: Canvas, x: Float, y: Float, a: Float, l1: Float, l2: Float, bend: Float) {
        val jx = x + sin(a) * l1; val jy = y + cos(a) * l1
        val a2 = a + bend * (if (abs(a) < .05f) 1f else sign(a))
        val ex = jx + sin(a2) * l2; val ey = jy + cos(a2) * l2
        c.drawLine(x, y, jx, jy, p); c.drawLine(jx, jy, ex, ey, p)
    }
}

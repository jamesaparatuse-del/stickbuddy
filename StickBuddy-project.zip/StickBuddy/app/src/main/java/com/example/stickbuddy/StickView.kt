package com.example.stickbuddy

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

private class Pose {
    var la = 0f; var ra = 0f; var ll = 0f; var rl = 0f
    var lab = 0.5f; var rab = 0.5f
    var lean = 0f; var oy = 0f; var rot = 0f; var pivot = 0
    var mouth = 0; var eyes = 0; var sit = false; var stars = false
    fun reset() {
        la = 0f; ra = 0f; ll = 0f; rl = 0f; lab = 0.5f; rab = 0.5f
        lean = 0f; oy = 0f; rot = 0f; pivot = 0; mouth = 0; eyes = 0; sit = false; stars = false
    }
}

/** رسم آدمک سفید بامزه + لمس و کشیدن. */
class StickView(ctx: Context, private val b: Buddy) : View(ctx) {
    private val ol = 0xFF222222.toInt()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val lines = ArrayList<FloatArray>()
    private val dots = ArrayList<FloatArray>()
    private val p = Pose()
    private val rect = RectF()
    private val path = Path()
    private val PI_F = Math.PI.toFloat()

    private var dx = 0f
    private var dy = 0f
    private var moved = false

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; moved = false }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && (abs(e.rawX - dx) > 14f * b.u || abs(e.rawY - dy) > 14f * b.u)) { moved = true; b.grab(dx, dy) }
                if (moved) b.dragTo(e.rawX, e.rawY)
            }
            MotionEvent.ACTION_UP -> { if (moved) b.release() else b.poke() }
            MotionEvent.ACTION_CANCEL -> { if (moved) b.release() }
        }
        return true
    }

    private fun legBend(a: Float): Float = if (p.sit) 0.05f else -(0.25f + 0.45f * abs(a))

    private fun limb(x: Float, y: Float, a: Float, l1: Float, l2: Float, bend: Float, endR: Float) {
        val jx = x + sin(a) * l1
        val jy = y + cos(a) * l1
        val a2 = a + bend
        val ex = jx + sin(a2) * l2
        val ey = jy + cos(a2) * l2
        lines.add(floatArrayOf(x, y, jx, jy))
        lines.add(floatArrayOf(jx, jy, ex, ey))
        dots.add(floatArrayOf(ex, ey, endR))
    }

    private fun computePose() {
        p.reset()
        val t = b.t
        val pr = if (b.dur > 0f) (t / b.dur).coerceIn(0f, 1f) else 0f
        val u = b.u
        val sad = b.mood < 0.35f
        when (b.act) {
            Act.IDLE -> {
                if (b.loc == Loc.WALL) {
                    p.lean = 0.08f; p.la = 2.5f; p.ra = 2.8f; p.ll = 0.7f; p.rl = 0.15f; p.lab = 0.3f; p.rab = 0.3f
                } else {
                    p.oy = sin(t * 2.5f) * 0.8f * u
                    p.la = 0.12f; p.ra = -0.12f; p.ll = 0.05f; p.rl = -0.05f
                    if (sad) { p.mouth = 4; p.lean = 0.1f }
                }
            }
            Act.WALK -> {
                val s = sin(t * 9f)
                p.ll = s * 0.7f; p.rl = -s * 0.7f; p.la = -s * 0.6f; p.ra = s * 0.6f
                p.oy = -abs(s) * 2.5f * u
                if (sad) p.mouth = 4
            }
            Act.RUN -> {
                val s = sin(t * 14f)
                p.ll = s * 1.0f; p.rl = -s * 1.0f; p.la = -s * 1.0f; p.ra = s * 1.0f
                p.lean = 0.25f; p.oy = -abs(s) * 4f * u; p.mouth = 5; p.eyes = 5
            }
            Act.SIT -> {
                p.sit = true; p.ll = 1.45f; p.rl = 1.3f; p.la = 0.6f; p.ra = -0.3f
                p.oy = sin(t * 2f) * 0.5f * u; p.lean = -0.05f
                if (sad) p.mouth = 4
            }
            Act.SLEEP -> {
                p.rot = 90f; p.pivot = 1; p.la = 0.3f; p.ra = -0.2f; p.ll = 0.1f; p.rl = -0.1f
                p.eyes = 2; p.mouth = 3; p.oy = sin(t * 1.5f) * 0.5f * u
            }
            Act.WAVE -> { p.ra = 2.6f + sin(t * 13f) * 0.35f; p.la = 0.15f; p.ll = 0.08f; p.rl = -0.08f; p.mouth = 1 }
            Act.JUMP -> {
                p.oy = -sin(PI_F * pr) * 40f * u; p.la = 2.5f; p.ra = 2.5f; p.ll = 0.3f; p.rl = -0.3f; p.mouth = 1; p.eyes = 1
            }
            Act.FLIP -> {
                p.oy = -sin(PI_F * pr) * 45f * u; p.rot = pr * 360f; p.pivot = 2
                p.la = 2.4f; p.ra = 2.4f; p.ll = 0.9f; p.rl = 0.9f; p.mouth = 1; p.eyes = 1
            }
            Act.DANCE -> {
                val s = sin(t * 8f)
                p.oy = -abs(s) * 3f * u; p.la = 2.3f + s * 0.7f; p.ra = 2.3f - s * 0.7f
                p.ll = s * 0.5f; p.rl = -s * 0.5f; p.lean = s * 0.15f; p.mouth = 1; p.eyes = 1
            }
            Act.LAUGH -> {
                p.lean = -0.2f + sin(t * 28f) * 0.05f; p.oy = -abs(sin(t * 14f)) * 2.5f * u
                p.la = 0.6f; p.ra = 0.6f; p.mouth = 2; p.eyes = 1
            }
            Act.TRIP -> when {
                pr < 0.2f -> { p.lean = pr * 3f; p.la = 2.2f; p.ra = 2.2f; p.ll = 0.6f; p.mouth = 5; p.eyes = 5 }
                pr < 0.35f -> { p.rot = (pr - 0.2f) / 0.15f * 90f; p.pivot = 1; p.mouth = 5; p.eyes = 5; p.la = 2.4f; p.ra = 2.4f }
                pr < 0.8f -> { p.rot = 90f; p.pivot = 1; p.mouth = 4; p.eyes = 4; p.la = 2.6f; p.ra = 2.0f }
                else -> { p.rot = (1f - (pr - 0.8f) / 0.2f) * 90f; p.pivot = 1; p.mouth = 4 }
            }
            Act.KUNGFU -> {
                val cyc = (t * 1.6f).toInt() % 3
                p.eyes = 3
                when (cyc) {
                    0 -> { p.la = 1.55f; p.ra = 1.0f + sin(t * 14f) * 0.3f; p.ll = 0.5f; p.rl = -0.5f; p.lean = 0.1f; p.mouth = 1 }
                    1 -> { p.rl = 1.5f; p.ll = -0.1f; p.lean = -0.25f; p.la = 2.2f; p.ra = -1.0f; p.mouth = 2 }
                    else -> { p.la = 2.0f; p.ra = 2.0f; p.ll = 0.6f; p.rl = -0.6f; p.mouth = 1 }
                }
            }
            Act.WRESTLE -> {
                p.lean = 0.45f; p.la = 1.5f + sin(t * 10f) * 0.3f; p.ra = 1.5f - sin(t * 10f) * 0.3f
                p.ll = 0.6f; p.rl = -0.4f; p.oy = sin(t * 20f) * 0.8f * u; p.mouth = 4; p.eyes = 3
            }
            Act.VICTORY -> {
                p.la = 0.2f; p.ra = 2.9f; p.oy = -abs(sin(t * 6f)) * 3f * u; p.mouth = 1; p.eyes = 1
            }
            Act.ANGRY -> {
                val s = sin(t * 14f)
                p.ll = max(0f, s) * 0.4f; p.la = 2.4f + sin(t * 20f) * 0.3f; p.ra = 0.8f
                p.lean = 0.15f; p.mouth = 4; p.eyes = 3
            }
            Act.THINK -> { p.ra = 0.4f; p.rab = 2.4f; p.la = 0.1f; p.lean = -0.05f; p.oy = sin(t * 2.5f) * 0.8f * u; p.mouth = 3 }
            Act.STRETCH -> { p.la = 2.9f; p.ra = 2.9f; p.lean = -0.15f + sin(t * 3f) * 0.05f; p.mouth = 5; p.eyes = 1 }
            Act.SIGH -> { p.lean = 0.2f; p.oy = sin(t * 1.5f) * 0.8f * u; p.mouth = 4 }
            Act.DIZZY -> {
                p.lean = sin(t * 5f) * 0.2f; p.la = 1.2f; p.ra = -0.6f; p.mouth = 5; p.eyes = 4; p.stars = true
                p.ll = sin(t * 5f) * 0.2f; p.rl = -sin(t * 5f) * 0.2f
            }
            Act.LAND -> { p.oy = (1f - pr) * 9f * u; p.ll = 0.5f; p.rl = -0.5f; p.la = 1.2f; p.ra = -0.8f; p.mouth = 5 }
            Act.CLIMB -> {
                val s = sin(t * 6f)
                p.lean = 0.08f; p.la = 2.5f + s * 0.4f; p.ra = 2.5f - s * 0.4f
                p.ll = 0.7f + s * 0.4f; p.rl = 0.7f - s * 0.4f; p.lab = 0.3f; p.rab = 0.3f
                p.eyes = 5
            }
            Act.HANG -> {
                val s = sin(t * 2f)
                p.la = 3.0f; p.ra = 3.3f; p.lab = 0f; p.rab = 0f
                p.ll = s * 0.18f; p.rl = -s * 0.18f + 0.1f; p.rot = s * 6f; p.pivot = 3
            }
            Act.SHUFFLE -> {
                val s = sin(t * 5f)
                p.la = 3.14f - 0.6f * max(0f, s); p.ra = 3.14f - 0.6f * max(0f, -s)
                p.lab = 0f; p.rab = 0f; p.ll = s * 0.3f; p.rl = -s * 0.3f; p.rot = s * 3f; p.pivot = 3
            }
            Act.HELD -> {
                val s = sin(t * 5f)
                p.la = 3.0f; p.ra = 3.3f; p.lab = 0f; p.rab = 0f
                p.ll = s * 0.5f; p.rl = -s * 0.5f; p.rot = s * 9f; p.pivot = 3
                p.eyes = 5; p.mouth = if (b.silly > 0.5f) 2 else 5
            }
            Act.FALLING -> {
                val s = sin(t * 18f)
                p.la = 2.6f + s * 0.4f; p.ra = 2.6f - s * 0.4f; p.ll = s * 0.7f; p.rl = -s * 0.7f
                p.rot = sin(t * 9f) * 10f; p.pivot = 2; p.mouth = 5; p.eyes = 5
            }
        }
    }

    override fun onDraw(c: Canvas) {
        val u = b.u
        lines.clear(); dots.clear()
        computePose()
        val L = 32f * u; val T = 34f * u; val A = 26f * u; val R = 14f * u
        val h = height.toFloat()
        val bottom = h - 5f * u
        val hang = b.loc == Loc.CEIL || b.loc == Loc.HELD
        val neckTop = A + 2f * u
        val hipY = when {
            hang -> neckTop + T
            p.sit -> bottom - 3f * u
            else -> bottom - L + p.oy
        }
        var cx = width / 2f
        if (b.loc == Loc.WALL) cx = if (b.wallSide < 0) 36f * u else width - 36f * u

        c.save()
        c.translate(cx, 0f)
        c.scale(b.dir.toFloat(), 1f)
        if (p.pivot == 1) {
            val f = abs(p.rot) / 90f
            c.translate(-f * 38f * u, -f * 3f * u)
        }
        if (p.rot != 0f) {
            val pivY = when (p.pivot) { 1 -> bottom; 2 -> hipY - T / 2f; 3 -> 6f * u; else -> hipY }
            c.rotate(p.rot, 0f, pivY)
        }

        val nx = sin(p.lean) * T
        val ny = hipY - cos(p.lean) * T
        lines.add(floatArrayOf(0f, hipY, nx, ny))
        limb(0f, hipY, p.ll, L / 2f, L / 2f, legBend(p.ll), 3.4f * u)
        limb(0f, hipY, p.rl, L / 2f, L / 2f, legBend(p.rl), 3.4f * u)
        val sy = ny + 4f * u
        limb(nx, sy, p.la, A / 2f, A / 2f, p.lab, 3.2f * u)
        limb(nx, sy, p.ra, A / 2f, A / 2f, p.rab, 3.2f * u)
        val hx = nx + sin(p.lean) * R
        val hy = ny - cos(p.lean) * R

        // دور تیره
        paint.color = ol; paint.style = Paint.Style.STROKE; paint.strokeWidth = 9f * u
        for (l in lines) c.drawLine(l[0], l[1], l[2], l[3], paint)
        paint.style = Paint.Style.FILL
        for (d in dots) c.drawCircle(d[0], d[1], d[2] + 2f * u, paint)
        // رنگ آدمک
        paint.color = b.color; paint.style = Paint.Style.STROKE; paint.strokeWidth = 5f * u
        for (l in lines) c.drawLine(l[0], l[1], l[2], l[3], paint)
        paint.style = Paint.Style.FILL
        for (d in dots) c.drawCircle(d[0], d[1], d[2], paint)
        // سر
        paint.color = b.color; paint.style = Paint.Style.FILL
        c.drawCircle(hx, hy, R, paint)
        paint.color = ol; paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f * u
        c.drawCircle(hx, hy, R, paint)
        // فرِ بامزه روی سر
        path.reset()
        path.moveTo(hx, hy - R + 1f * u)
        path.quadTo(hx + 2f * u, hy - R - 9f * u, hx + 8f * u, hy - R - 6f * u)
        paint.strokeWidth = 2.5f * u
        c.drawPath(path, paint)
        drawFace(c, hx, hy, R, u)
        if (p.stars) {
            paint.style = Paint.Style.FILL; paint.color = 0xFFFFC83D.toInt()
            for (k in 0..2) {
                val ang = b.t * 4f + k * 2.1f
                c.drawCircle(hx + cos(ang) * 18f * u, hy - R - 4f * u + sin(ang) * 4f * u, 2.2f * u, paint)
            }
        }
        c.restore()

        if (b.act == Act.SLEEP && b.loc == Loc.GROUND) {
            paint.style = Paint.Style.FILL; paint.color = ol
            val f = (b.clock * 0.8f) % 1f
            for (k in 0..2) {
                val ff = (f + k / 3f) % 1f
                paint.alpha = (255 * (1f - ff)).toInt()
                paint.textSize = (9f + k * 4f) * u
                c.drawText("Z", cx + b.dir * (30f + k * 8f) * u, h - (36f + ff * 40f) * u, paint)
            }
            paint.alpha = 255
        }
    }

    private fun drawFace(c: Canvas, hx: Float, hy: Float, R: Float, u: Float) {
        val e1 = hx + 1.5f * u
        val e2 = hx + 8f * u
        val ey = hy - 1.5f * u
        val blink = (b.clock % 4f) < 0.12f
        paint.color = ol
        for (k in 0..1) {
            val ex = if (k == 0) e1 else e2
            when (if (blink && p.eyes == 0) 2 else p.eyes) {
                0 -> {
                    paint.style = Paint.Style.FILL; paint.color = ol
                    c.drawCircle(ex, ey, 2.3f * u, paint)
                    paint.color = 0xFFFFFFFF.toInt(); c.drawCircle(ex - 0.7f * u, ey - 0.8f * u, 0.8f * u, paint)
                }
                1 -> {
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f * u; paint.color = ol
                    rect.set(ex - 2.5f * u, ey - 1.5f * u, ex + 2.5f * u, ey + 2.5f * u)
                    c.drawArc(rect, 200f, 140f, false, paint)
                }
                2 -> {
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f * u; paint.color = ol
                    c.drawLine(ex - 2.5f * u, ey, ex + 2.5f * u, ey, paint)
                }
                3 -> {
                    paint.style = Paint.Style.FILL; paint.color = ol
                    c.drawCircle(ex, ey + 0.5f * u, 2.1f * u, paint)
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f * u
                    if (k == 0) c.drawLine(ex - 3f * u, ey - 4.5f * u, ex + 2.5f * u, ey - 2.5f * u, paint)
                    else c.drawLine(ex - 2.5f * u, ey - 2.5f * u, ex + 3f * u, ey - 4.5f * u, paint)
                }
                4 -> {
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.8f * u; paint.color = ol
                    c.drawLine(ex - 2f * u, ey - 2f * u, ex + 2f * u, ey + 2f * u, paint)
                    c.drawLine(ex - 2f * u, ey + 2f * u, ex + 2f * u, ey - 2f * u, paint)
                }
                else -> {
                    paint.style = Paint.Style.FILL; paint.color = 0xFFFFFFFF.toInt()
                    c.drawCircle(ex, ey, 3.4f * u, paint)
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.6f * u; paint.color = ol
                    c.drawCircle(ex, ey, 3.4f * u, paint)
                    paint.style = Paint.Style.FILL; c.drawCircle(ex + 0.5f * u, ey, 1.5f * u, paint)
                }
            }
        }
        // گونه‌ی صورتی
        paint.style = Paint.Style.FILL; paint.color = 0xFFFF9AA8.toInt(); paint.alpha = 190
        c.drawCircle(hx + 5f * u, hy + 4.5f * u, 2.6f * u, paint)
        paint.alpha = 255
        // دهان
        val mx = hx + 5.5f * u
        val my = hy + 5.5f * u
        paint.color = ol
        when (p.mouth) {
            0 -> { paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f * u; rect.set(mx - 3f * u, my - 2f * u, mx + 3f * u, my + 2f * u); c.drawArc(rect, 20f, 140f, false, paint) }
            1 -> { paint.style = Paint.Style.FILL; rect.set(mx - 3.5f * u, my - 3f * u, mx + 3.5f * u, my + 3f * u); c.drawArc(rect, 0f, 180f, true, paint) }
            2 -> { paint.style = Paint.Style.FILL; rect.set(mx - 3.5f * u, my - 2.5f * u, mx + 3.5f * u, my + 3.5f * u); c.drawOval(rect, paint)
                paint.color = 0xFFFF7A8A.toInt(); c.drawCircle(mx, my + 2f * u, 1.6f * u, paint) }
            3 -> { paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f * u; c.drawLine(mx - 2f * u, my, mx + 2f * u, my, paint) }
            4 -> { paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f * u; rect.set(mx - 3f * u, my, mx + 3f * u, my + 4f * u); c.drawArc(rect, 200f, 140f, false, paint) }
            else -> { paint.style = Paint.Style.FILL; c.drawCircle(mx, my + 0.5f * u, 2.2f * u, paint) }
        }
    }
}

package com.example.stickbuddy

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("buddy", Context.MODE_PRIVATE)
    var size: Float
        get() = sp.getFloat("size", 1f)
        set(v) { sp.edit().putFloat("size", v).apply() }
    var speed: Float
        get() = sp.getFloat("speed", 1f)
        set(v) { sp.edit().putFloat("speed", v).apply() }
    var color: Int
        get() = sp.getInt("color", 0xFFFFFFFF.toInt())
        set(v) { sp.edit().putInt("color", v).apply() }
    var count: Int
        get() = sp.getInt("count", 1)
        set(v) { sp.edit().putInt("count", v).apply() }
    var boot: Boolean
        get() = sp.getBoolean("boot", false)
        set(v) { sp.edit().putBoolean("boot", v).apply() }
    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) { sp.edit().putBoolean("enabled", v).apply() }
}

package com.example.stickbuddy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class OverlayService : Service() {
    companion object {
        var running = false
        const val ACTION_STOP = "stop"
        const val ACTION_RELOAD = "reload"
        val PALETTE = intArrayOf(
            0xFFFFFFFF.toInt(), 0xFFFFE066.toInt(), 0xFFFFB3C7.toInt(), 0xFF8EE3FF.toInt(),
            0xFFA8F0A8.toInt(), 0xFFFFB366.toInt(), 0xFFD1B3FF.toInt()
        )
    }

    private class Win(
        val b: Buddy, val v: StickView, val bv: BubbleView,
        val lp: WindowManager.LayoutParams, val blp: WindowManager.LayoutParams
    )

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val wins = ArrayList<Win>()
    private var lastT = 0L

    private val tick = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            val dt = ((now - lastT) / 1000f).coerceIn(0.001f, 0.1f)
            lastT = now
            val dm = resources.displayMetrics
            val st = statusH()
            val all = ArrayList<Buddy>()
            for (w in wins) all.add(w.b)
            for (w in wins) {
                val b = w.b
                if (b.sw != dm.widthPixels || b.sh != dm.heightPixels) b.setScreen(dm.widthPixels, dm.heightPixels, st)
                b.update(dt, all)
                w.lp.x = b.x.toInt(); w.lp.y = b.y.toInt()
                try { wm.updateViewLayout(w.v, w.lp) } catch (_: Exception) {}
                w.v.invalidate()
                updateBubble(w, dm.widthPixels, dm.heightPixels, st)
            }
            handler.postDelayed(this, 33)
        }
    }

    private fun statusH(): Float {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id).toFloat() else 24f * resources.displayMetrics.density
    }

    private fun updateBubble(w: Win, sw: Int, sh: Int, st: Float) {
        val b = w.b
        val s = b.say
        if (s == null) {
            if (w.bv.visibility != View.GONE) w.bv.visibility = View.GONE
            return
        }
        val bw = w.blp.width
        val bh = w.blp.height
        val bx = (b.x + b.wPx / 2f - bw / 2f).coerceIn(0f, (sw - bw).toFloat().coerceAtLeast(0f))
        var by = b.y - bh
        var below = false
        if (b.loc == Loc.CEIL || by < st) { by = b.y + b.hPx - 8f * b.u; below = true }
        by = by.coerceIn(0f, (sh - bh).toFloat().coerceAtLeast(0f))
        w.bv.text = s
        w.bv.below = below
        w.bv.tailX = b.x + b.wPx / 2f - bx
        w.blp.x = bx.toInt(); w.blp.y = by.toInt()
        try { wm.updateViewLayout(w.bv, w.blp) } catch (_: Exception) {}
        if (w.bv.visibility != View.VISIBLE) w.bv.visibility = View.VISIBLE
        w.bv.invalidate()
    }

    private fun build() {
        val pr = Prefs(this)
        val dm = resources.displayMetrics
        val u = dm.density * pr.size
        val bu = dm.density * pr.size.coerceAtMost(1.2f)
        val ww = (96f * u).toInt()
        val hh = (118f * u).toInt()
        val names = listOf("چوبی", "فندقی", "شیطون", "پشمالو").shuffled()
        val others = PALETTE.filter { it != pr.color }
        for (i in 0 until pr.count.coerceIn(1, 3)) {
            val b = Buddy(names[i], u, pr.speed, ww, hh)
            b.color = if (i == 0) pr.color else others[(i - 1) % others.size]
            val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            val lp = WindowManager.LayoutParams(ww, hh, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.TOP or Gravity.START
            val bflags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            val blp = WindowManager.LayoutParams((190f * bu).toInt(), (74f * bu).toInt(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, bflags, PixelFormat.TRANSLUCENT)
            blp.gravity = Gravity.TOP or Gravity.START
            val v = StickView(this, b)
            val bv = BubbleView(this, bu)
            bv.visibility = View.GONE
            b.setScreen(dm.widthPixels, dm.heightPixels, statusH())
            lp.x = b.x.toInt(); lp.y = b.y.toInt()
            wm.addView(v, lp)
            wm.addView(bv, blp)
            wins.add(Win(b, v, bv, lp, blp))
        }
        lastT = SystemClock.uptimeMillis()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private fun clear() {
        handler.removeCallbacks(tick)
        for (w in wins) {
            try { wm.removeView(w.v) } catch (_: Exception) {}
            try { wm.removeView(w.bv) } catch (_: Exception) {}
        }
        wins.clear()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val pr = Prefs(this)
        if (i?.action == ACTION_STOP) {
            pr.enabled = false
            stopSelf()
            return START_NOT_STICKY
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startNotif()
        if (i?.action == ACTION_RELOAD) clear()
        if (wins.isEmpty()) build()
        pr.enabled = true
        running = true
        return START_STICKY
    }

    private fun startNotif() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("buddy", "Stick Buddy", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "buddy")
            .setContentTitle("دوست استیک‌من روشن است")
            .setSmallIcon(android.R.drawable.star_on)
            .addAction(Notification.Action.Builder(null, "خاموش", stop).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    override fun onDestroy() {
        clear()
        running = false
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}

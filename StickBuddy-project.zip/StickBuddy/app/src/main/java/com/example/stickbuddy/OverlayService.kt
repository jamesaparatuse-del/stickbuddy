package com.example.stickbuddy

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import kotlin.random.Random

class OverlayService : Service() {
    companion object { var running = false; const val ACTION_STOP = "stop" }

    private lateinit var wm: WindowManager
    private var view: StickView? = null
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var x = 0f
    private var screenW = 0
    private val speed get() = 90f * resources.displayMetrics.density

    private val tick = object : Runnable {
        override fun run() {
            val v = view ?: return
            val dt = 0.033f
            v.step(dt)
            if (v.act == "walk") x += v.dir * speed * dt
            val maxX = (screenW - lp.width).toFloat()
            if (x < 0) { x = 0f; v.dir = 1 }
            if (x > maxX) { x = maxX; v.dir = -1 }
            if (v.finished()) pickNext(v)
            lp.x = x.toInt()
            try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
            handler.postDelayed(this, 33)
        }
    }

    private fun pickNext(v: StickView) {
        val a = listOf("walk", "walk", "walk", "jump", "dance", "flip", "fall", "wave", "laugh", "sneak").random()
        if (a == "walk" && Random.nextBoolean()) v.dir = -v.dir
        v.start(a)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startNotif()
        if (view == null) addView()
        running = true
        return START_STICKY
    }

    private fun addView() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics
        screenW = d.widthPixels
        val v = StickView(this)
        val w = (130 * d.density).toInt(); val h = (150 * d.density).toInt()
        lp = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            y = d.heightPixels - h - (64 * d.density).toInt()
        }
        x = Random.nextInt(0, (screenW - w).coerceAtLeast(1)).toFloat()
        lp.x = x.toInt()
        v.setOnClickListener { v.start(listOf("jump", "flip", "laugh", "fall", "dance", "sneak").random()) }
        wm.addView(v, lp)
        view = v
        v.start("wave")
        handler.post(tick)
    }

    private fun startNotif() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("buddy", "Stick Buddy", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "buddy")
            .setContentTitle("دوست استیک‌من روشن است")
            .setSmallIcon(android.R.drawable.star_on)
            .addAction(Notification.Action.Builder(null, "خاموش", stop).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null; running = false
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}

package com.example.stickbuddy

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var btn: Button
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding((24 * d).toInt(), 0, (24 * d).toInt(), 0)
        }
        root.addView(TextView(this).apply {
            text = "دوست استیک‌من 🕺"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "یک آدمک سیاه روی صفحه‌ی گوشی راه می‌رود، می‌پرد، می‌رقصد و کارهای خنده‌دار می‌کند. روی او بزنی، یک کار جدید می‌کند."
            textSize = 15f; gravity = Gravity.CENTER; setPadding(0, (12 * d).toInt(), 0, (24 * d).toInt())
        })
        btn = Button(this).apply { textSize = 18f; setOnClickListener { toggle() } }
        root.addView(btn)
        status = TextView(this).apply { gravity = Gravity.CENTER; setPadding(0, (16 * d).toInt(), 0, 0) }
        root.addView(status)
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        btn.text = if (OverlayService.running) "خاموش کن" else "روشن کن"
        status.text = if (OverlayService.running) "الان روشن است ✅" else "الان خاموش است"
    }

    private fun toggle() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            OverlayService.running = false
        } else {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                status.text = "اجازه‌ی «نمایش روی برنامه‌های دیگر» را بده و برگرد"
                return
            }
            startForegroundService(Intent(this, OverlayService::class.java))
            OverlayService.running = true
        }
        refresh()
    }
}

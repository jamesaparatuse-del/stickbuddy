package com.example.stickbuddy

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var btn: Button
    private lateinit var status: TextView
    private val swatches = ArrayList<View>()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(24), dp(36), dp(24), dp(36))
        }
        root.addView(TextView(this).apply {
            text = "دوست استیک‌من 🕺"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "یک آدمک سفید بامزه که روی صفحه‌ی گوشی زندگی می‌کند: راه می‌رود، استراحت می‌کند، از دیوار بالا می‌رود، آویزان می‌شود و گاهی کارهای خنده‌دار می‌کند. می‌توانی با انگشت جابه‌جایش کنی یا قلقلکش بدهی!"
            textSize = 14f; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(18))
        })
        btn = Button(this).apply { textSize = 18f; setOnClickListener { toggle() } }
        root.addView(btn)
        status = TextView(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(20)) }
        root.addView(status)

        addSeek(root, "اندازه", 60, 200, (prefs.size * 100).toInt()) { prefs.size = it / 100f }
        addSeek(root, "سرعت", 50, 200, (prefs.speed * 100).toInt()) { prefs.speed = it / 100f }
        addSeek(root, "تعداد آدمک‌ها", 1, 3, prefs.count) { prefs.count = it }

        root.addView(TextView(this).apply { text = "رنگ آدمک"; textSize = 15f; setPadding(0, dp(16), 0, dp(6)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        for (col in OverlayService.PALETTE) {
            val v = View(this)
            val lp = LinearLayout.LayoutParams(dp(38), dp(38)); lp.setMargins(dp(4), 0, dp(4), 0)
            v.layoutParams = lp
            v.tag = col
            v.setOnClickListener { prefs.color = col; refreshSwatches(); reload() }
            swatches.add(v); row.addView(v)
        }
        root.addView(row)
        refreshSwatches()

        val sw = Switch(this).apply {
            text = "روشن شدن خودکار بعد از ریستارت گوشی"
            isChecked = prefs.boot
            setPadding(0, dp(22), 0, 0)
            setOnCheckedChangeListener { _, v -> prefs.boot = v }
        }
        root.addView(sw)

        setContentView(ScrollView(this).apply { addView(root) })
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    private fun addSeek(root: LinearLayout, label: String, lo: Int, hi: Int, cur: Int, onSet: (Int) -> Unit) {
        val tv = TextView(this).apply { textSize = 15f; setPadding(0, dp(16), 0, 0) }
        val unit = if (hi > 10) "٪" else ""
        val start = cur.coerceIn(lo, hi)
        tv.text = label + ": " + start + unit
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = start - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { tv.text = label + ": " + (p + lo) + unit }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { onSet((s?.progress ?: 0) + lo); reload() }
        })
        root.addView(tv); root.addView(sb)
    }

    private fun refreshSwatches() {
        for (v in swatches) {
            val col = v.tag as Int
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(col)
            g.setStroke(if (col == prefs.color) dp(4) else dp(2), if (col == prefs.color) Color.parseColor("#1565C0") else Color.parseColor("#555555"))
            v.background = g
        }
    }

    private fun reload() {
        if (OverlayService.running) {
            startForegroundService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_RELOAD))
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        btn.text = if (OverlayService.running) "خاموش کن" else "روشن کن"
        status.text = if (OverlayService.running) "الان روشن است ✅" else "الان خاموش است"
    }

    private fun toggle() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            OverlayService.running = false
        } else {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                status.text = "اجازه‌ی «نمایش روی برنامه‌های دیگر» را بده و برگرد"
                return
            }
            startForegroundService(Intent(this, OverlayService::class.java))
            OverlayService.running = true
        }
        refresh()
    }
}

package com.example.stickbuddy

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View

/** حباب حرف زدن (پنجره‌ی جدا، بدون لمس). */
class BubbleView(ctx: Context, private val bu: Float) : View(ctx) {
    var text: String? = null
    var below = false
    var tailX = 0f
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF222222.toInt(); textSize = 13f * bu }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF222222.toInt(); style = Paint.Style.STROKE; strokeWidth = 2f * bu }
    private val rect = RectF()
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val s = text ?: return
        val maxW = (width - 24f * bu).toInt().coerceAtLeast(40)
        val lay = StaticLayout.Builder.obtain(s, 0, s.length, tp, maxW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        var tw = 0f
        for (i in 0 until lay.lineCount) { if (lay.getLineWidth(i) > tw) tw = lay.getLineWidth(i) }
        val pad = 8f * bu
        val bw = tw + pad * 2
        val bh = lay.height + pad * 2
        val left = (width - bw) / 2f
        val top = if (below) 10f * bu else height - bh - 10f * bu
        rect.set(left, top, left + bw, top + bh)
        val tx = tailX.coerceIn(left + 12f * bu, left + bw - 12f * bu)
        path.reset()
        if (below) {
            path.moveTo(tx - 6f * bu, top); path.lineTo(tx, top - 8f * bu); path.lineTo(tx + 6f * bu, top)
        } else {
            path.moveTo(tx - 6f * bu, top + bh); path.lineTo(tx, top + bh + 8f * bu); path.lineTo(tx + 6f * bu, top + bh)
        }
        c.drawRoundRect(rect, 10f * bu, 10f * bu, fill)
        c.drawPath(path, fill)
        c.drawRoundRect(rect, 10f * bu, 10f * bu, stroke)
        c.drawPath(path, stroke)
        // پوشاندن خط بین دم و حباب
        val old = stroke.color
        stroke.color = 0xFFFFFFFF.toInt()
        if (below) c.drawLine(tx - 5f * bu, top, tx + 5f * bu, top, stroke)
        else c.drawLine(tx - 5f * bu, top + bh, tx + 5f * bu, top + bh, stroke)
        stroke.color = old
        c.save()
        c.translate(left + pad, top + pad)
        lay.draw(c)
        c.restore()
    }
}
